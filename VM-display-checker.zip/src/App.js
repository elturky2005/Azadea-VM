import React, { useState } from "react";
import { Camera } from "lucide-react";
import { motion } from "framer-motion";

export default function DisplayCheckApp() {
  const [image, setImage] = useState(null);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (file) {
      setImage(URL.createObjectURL(file));
      setLoading(true);

      try {
        // Simulate detection result (replace with actual API later)
        await new Promise((res) => setTimeout(res, 1000));
        setResults([
          { name: "Dior Lipstick", status: "correct" },
          { name: "Chanel Perfume", status: "misplaced" },
          { name: "YSL Foundation", status: "missing" }
        ]);
      } catch (error) {
        console.error("Error analyzing image:", error);
        setResults([]);
      } finally {
        setLoading(false);
      }
    }
  };

  const statusColor = {
    correct: "green",
    misplaced: "orange",
    missing: "red"
  };

  return (
    <div style={{ padding: 20, maxWidth: 600, margin: "0 auto" }}>
      <h1 style={{ fontSize: 24, marginBottom: 20 }}>Makeup & Perfume Display Checker</h1>

      <div style={{ background: "#fff", padding: 20, borderRadius: 12, boxShadow: "0 2px 8px rgba(0,0,0,0.1)" }}>
        <input type="file" accept="image/*" onChange={handleImageUpload} />
        {image && <img src={image} alt="Uploaded" style={{ borderRadius: 12, marginTop: 20 }} />}
        <button
          disabled={loading}
          style={{
            marginTop: 20,
            padding: "10px 20px",
            border: "none",
            background: "#1e40af",
            color: "white",
            borderRadius: 8,
            cursor: "pointer"
          }}
        >
          <Camera style={{ marginRight: 8 }} />
          {loading ? "Analyzing..." : "Analyze Display"}
        </button>
      </div>

      {results.length > 0 && (
        <div style={{ marginTop: 30 }}>
          <h2 style={{ fontSize: 20, marginBottom: 10 }}>Detection Results</h2>
          <ul style={{ listStyle: "none", padding: 0 }}>
            {results.map((item, index) => (
              <motion.li
                key={index}
                style={{
                  background: "#fff",
                  marginBottom: 10,
                  padding: 12,
                  borderRadius: 10,
                  borderLeft: `5px solid ${statusColor[item.status]}`,
                  boxShadow: "0 1px 4px rgba(0,0,0,0.05)"
                }}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.2 }}
              >
                {item.name}: {item.status.toUpperCase()}
              </motion.li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
